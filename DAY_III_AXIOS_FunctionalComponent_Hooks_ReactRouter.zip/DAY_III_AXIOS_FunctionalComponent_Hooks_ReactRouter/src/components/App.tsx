import React from "react";
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import { ProductCard } from "./card.component";
import Counter from "./counter.statehook";
import { FormMessage } from "./formmessage.component";
import { BasicFunctionalComponent } from "./functional.component";
import Getpostbyid from "./getpostbyid.component";
import ListOfCourses from "./listofcourses.component";
import { NewCourse } from "./newcourse.component";
import Postdetails from "./post.details";
import { Posts } from "./posts.component";
import PostsWithEffect from "./posts.functional";

class App extends React.Component {
  render(): React.ReactNode {
    return (
      <>
        <BrowserRouter>
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <div className="container-fluid">
              <Link className="navbar-brand" to="/">
                Online Training
              </Link>
              <button
                className="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNav"
                aria-controls="navbarNav"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className="collapse navbar-collapse" id="navbarNav">
                <ul className="navbar-nav">
                  <li className="nav-item">
                    <Link className="nav-link" aria-current="page" to="/">
                      Courses
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link" to="/posts">
                      Posts
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link" to="/newcourse">
                      New Course
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
          <Routes>
            <Route path="/" element={<ListOfCourses />}></Route>
            <Route path="/posts" element={<Posts />}></Route>
            <Route path="/newcourse" element={<NewCourse />}></Route>
            <Route path="/products" element={<ProductCard />}></Route>

            <Route path="/postdetails/:id" element={<Postdetails />}></Route>
            <Route
              path="*"
              element={
                <>
                  <h1 style={{ color: "red" }}> Resource not found ! 404 !</h1>
                  <img
                    height="200px"
                    width="300px"
                    src="https://www.lifewire.com/thmb/pGMhoCAF5a56wvVtPAWct8HdUPc=/3000x2000/filters:fill(auto,1)/404-not-found-error-explained-2622936-Final-fde7be1b7e2e499c9f039d97183e7f52.jpg"
                  />
                </>
              }
            ></Route>
          </Routes>
        </BrowserRouter>
      </>
    );
  }
}

export default App;

// class App extends React.Component {
//   render(): React.ReactNode {
//     return (
//       <div>
//         <ListOfCourses />
//         <FormMessage />
//         <Posts />
//         {/* <BasicFunctionalComponent msg="Functional Component rendered !" /> */}
//         {/* <Counter /> */}
//         {/* <PostsWithEffect />
//         <Getpostbyid /> */}
//       </div>
//     );
//   }
// }

// export default App;
