import React, { useEffect, useState } from "react";
import axios from "axios";
// componentDidMount , componentDidUpdate
export default function PostsWithEffect() {
  const [posts, setPosts] = useState([]);
  useEffect(() => {
    let thePromise = axios.get("https://jsonplaceholder.typicode.com/posts");
    thePromise
      .then((response) => {
        console.log("Within the of axios success callback !");
        setPosts(response.data);
      })
      .catch((err) => console.log(err));
  }, []);

  let allPostsToBeCreated = posts.map((p: any) => (
    <li key={p.id} className="list-group-item">
      {p.title}
    </li>
  ));
  return (
    <div>
      <h1>All Posts (useEffect)</h1>
      <ul>{allPostsToBeCreated}</ul>
    </div>
  );
}
