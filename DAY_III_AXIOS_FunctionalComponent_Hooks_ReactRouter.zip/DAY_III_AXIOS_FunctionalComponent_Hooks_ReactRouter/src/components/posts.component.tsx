import React, { ReactNode } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

export class Posts extends React.Component {
  state: Readonly<any> = { posts: [] };

  componentDidMount() {
    let thePromise = axios.get("https://jsonplaceholder.typicode.com/posts");
    thePromise
      .then((response) => {
        this.setState({ posts: response.data });
      })
      .catch((err) => {
        console.log(err);
      });
  }
  render(): ReactNode {
    let allPostsToBeCreated = this.state.posts.map((p: any) => (
      <li key={p.id} className="list-group-item">
        <Link to={`/postdetails/${p.id}`}>{p.title}</Link>
      </li>
    ));
    let content = null;
    if (this.state.posts.length == 0) {
      content = (
        <img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" />
      );
    } else {
      content = <ul className="list-group">{allPostsToBeCreated}</ul>;
    }

    return (
      <div>
        <h1>All Posts</h1>
        {content}
      </div>
    );
  }
}
