import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

export default function Postdetails() {
  let { id } = useParams();
  const [post, setPost] = useState({ title: "", id: "", userId: "", body: "" });

  useEffect(() => {
    let thePromise = axios.get(
      `https://jsonplaceholder.typicode.com/posts/${id}`
    );
    thePromise
      .then((response: any) => {
        setPost({ ...response.data });
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  return (
    <div>
      <h1>Post Details for {id}</h1>
      <h3>User Id : {post.userId}</h3>
      <h3>Title : {post.title}</h3>
      <h3>Body : {post.body}</h3>
    </div>
  );
}
