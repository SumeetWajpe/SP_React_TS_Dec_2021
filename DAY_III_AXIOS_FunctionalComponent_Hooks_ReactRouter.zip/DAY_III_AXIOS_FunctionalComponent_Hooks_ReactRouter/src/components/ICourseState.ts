export interface ICourseState {
  currLikes: number;
}
