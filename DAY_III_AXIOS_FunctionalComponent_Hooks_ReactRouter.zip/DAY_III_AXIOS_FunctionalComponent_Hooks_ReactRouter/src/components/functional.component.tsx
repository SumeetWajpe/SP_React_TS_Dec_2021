// 1. no render
// 2. no access to this.state , this.setState -> 16.8 -> useState()
// 3. no access to this.props
// 4. no lifecyclemethods -> useEffect()
export function BasicFunctionalComponent(props: IMsgProps) {
  return <h1>{props.msg}</h1>;
}

interface IMsgProps {
  msg: string;
}
