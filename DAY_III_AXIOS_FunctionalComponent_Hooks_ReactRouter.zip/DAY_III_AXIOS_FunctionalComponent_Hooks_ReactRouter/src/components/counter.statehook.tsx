import React, { useState } from "react";
// 16.8 and above (useState)!
export default function Counter() {
  let [myState, setmyState] = useState({ count: 0, age: 18 });

  return (
    <div>
      <p>Count : {myState.count}</p>
      <p>Age: {myState.age}</p>
      <button
        className="btn btn-primary"
        onClick={() => setmyState({ ...myState, count: myState.count + 1 })}
      >
        Count++
      </button>
      <button
        className="btn btn-primary m-1"
        onClick={() => setmyState({ ...myState, age: myState.age + 10 })}
      >
        Age++
      </button>
    </div>
  );
}

// export default function Counter() {
//   let [count, setCount] = useState(0);
//   let [age, setAge] = useState(18);
//   return (
//     <div>
//       <p>Count : {count}</p>
//       <p>Age: {age}</p>
//       <button className="btn btn-primary" onClick={() => setCount(count + 1)}>
//         Count++
//       </button>
//       <button className="btn btn-primary m-1" onClick={() => setAge(age + 1)}>
//         Age++
//       </button>
//     </div>
//   );
// }
