import React from "react";

export function ProductCard(props: any) {
  return (
    <div>
      <Card>
        <CardHeader></CardHeader>
        <CardBody></CardBody>
      </Card>
      <hr />
      <Card>
        <CardHeader></CardHeader>
        <CardBody></CardBody>
        <CardActions></CardActions>
      </Card>
      <hr />
      <Card>
        <CardActions></CardActions>
      </Card>
    </div>
  );
}

export function Card(props: any) {
  return <div>{props.children}</div>;
}

export function CardHeader() {
  return <h2>Card Heading</h2>;
}

export function CardBody() {
  return <section>Card Body</section>;
}

export function CardActions() {
  return (
    <div>
      <button className="btn btn-success">Add</button>
      <button className="btn btn-danger">Delete</button>
    </div>
  );
}
