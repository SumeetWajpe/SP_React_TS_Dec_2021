import axios from "axios";
import React, { useState, useEffect } from "react";

export default function Getpostbyid() {
  const [thePost, setthePost] = useState({ title: "" });
  const [thePostId, setthePostId] = useState(1);
  useEffect(() => {
    let thePromise = axios.get(
      `https://jsonplaceholder.typicode.com/posts/${thePostId}`
    );
    thePromise.then((response) => setthePost(response.data));
  }, [thePostId]);

  // useEffect(() => {
  //   effect
  //   return () => {
  //     cleanup
  //   }
  // }, [input])
  return (
    <div>
      <label htmlFor="txtPostId">Post Id : </label>{" "}
      <input
        type="text"
        id="txtPostId"
        onInput={(e: any) => setthePostId(e.target.value)}
      />
      <p>{thePost.title}</p>
    </div>
  );
}
