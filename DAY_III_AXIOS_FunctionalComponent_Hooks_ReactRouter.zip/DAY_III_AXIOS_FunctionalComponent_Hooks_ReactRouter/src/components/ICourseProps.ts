import { CourseModel } from "../models/course.model";

export interface ICourseProps {
  coursedetails: CourseModel;
  DeleteAProduct: (theCourseId: number) => void;
}
