export class CourseModel {
  id: number = 0;
  title: string = "";
  price: number = 0;
  likes: number = 0;
  rating: number = 0;
  imageUrl: string = "";
}
