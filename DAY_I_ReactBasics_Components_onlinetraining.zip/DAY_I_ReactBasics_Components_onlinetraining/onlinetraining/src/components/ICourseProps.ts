import { CourseModel } from "../models/course.model";

export interface ICourseProps {
  coursedetails: CourseModel;
}
