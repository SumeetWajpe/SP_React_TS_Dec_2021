import React from "react";
import ListOfCourses from "./listofcourses.component";

class App extends React.Component {
  render(): React.ReactNode {
    return (
      <div>
        <ListOfCourses />
      </div>
    );
  }
}

export default App;
