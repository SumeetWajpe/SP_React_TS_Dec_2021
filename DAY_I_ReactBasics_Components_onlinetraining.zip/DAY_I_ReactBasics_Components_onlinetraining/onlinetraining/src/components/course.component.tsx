import React from "react";
import { ICourseProps } from "./ICourseProps";

class Course extends React.Component<ICourseProps> {
  render(): React.ReactNode {
    return (
      <div className="col-md-3">
        <h2>{this.props.coursedetails.title}</h2>
      </div>
    );
  }
}

export default Course;
