import React from "react";
export class Message extends React.Component<any> {
  render() {
    console.log("Within Message render");

    return (
      <div>
        <h2>{this.props.msg}</h2>
      </div>
    );
  }
}
