import React from "react";
import { CourseModel } from "../models/course.model";
import Course from "./course.component";
import { NewCourse } from "./newcourse.component";
class ListOfCourses extends React.Component {
  state: Readonly<any> = {
    courses: [
      {
        id: 1,
        title: "React",
        price: 5000,
        likes: 400,
        rating: 5,
        imageUrl:
          "https://ms314006.github.io/static/b7a8f321b0bbc07ca9b9d22a7a505ed5/97b31/React.jpg",
      },
      {
        id: 2,
        title: "Redux",
        price: 4000,
        likes: 600,
        rating: 5,
        imageUrl: "https://logicalidea.co/wp-content/uploads/2020/05/Redux.jpg",
      },
      {
        id: 3,
        title: "Node",
        price: 6000,
        likes: 900,
        rating: 4,
        imageUrl:
          "https://www.cloudsavvyit.com/p/uploads/2019/07/2350564e.png?width=1198&trim=1,1&bg-color=000&pad=1,1",
      },
      {
        id: 4,
        title: "Angular",
        price: 5000,
        likes: 200,
        rating: 3,
        imageUrl:
          "https://bs-uploads.toptal.io/blackfish-uploads/blog/post/seo/og_image_file/og_image/15991/top-18-most-common-angularjs-developer-mistakes-41f9ad303a51db70e4a5204e101e7414.png",
      },
      {
        id: 5,
        title: "Flutter",
        price: 7000,
        likes: 700,
        rating: 4,
        imageUrl:
          "https://miro.medium.com/max/2000/1*PCKC8Ufml-wvb9Vjj3aaWw.jpeg",
      },
    ],
  };

  DeleteAHandler(theCourseId: number) {
    console.log("Within Deletehandler of Listofcourses", theCourseId);

    //?? pass the id
    //?? update the array !

    // this.state.courses.splice(index,1) // wont work as we are updating the orginal array !

    let newCourses = this.state.courses.filter(
      (course: CourseModel) => course.id != theCourseId
    );
    this.setState({ courses: newCourses });
  }

  AddNewCourse(newCourse: CourseModel) {
    console.log(newCourse);
    //this.state.courses.push(newCourse); // won't work as we are updating the original object !
    this.setState({ courses: [...this.state.courses, newCourse] });
  }

  componentWillMount() {
    console.log("Within Component Will Mount :: List Of Courses!");
  }

  componentDidMount() {
    // AJAX , timers , integrate library / framework
    console.log("Within Component Did Mount :: List Of Courses!!");
  }

  shouldComponentUpdate() {
    if (this.state.courses.length == 1) {
      console.log("Within should Component update :: List Of Courses ");
      return false;
    }
    return true;
  }
  componentWillUpdate() {
    console.log("Within Component Will update :: List Of Courses ");
  }
  componentDidUpdate() {
    console.log("Within Component Did update :: List Of Courses ");
  }
  render(): React.ReactNode {
    console.log("Within Render :: List Of Courses!");

    var coursesToBeCreated = this.state.courses.map((course: CourseModel) => (
      <Course
        key={course.id}
        coursedetails={course}
        DeleteAProduct={(theCourseId: number) =>
          this.DeleteAHandler(theCourseId)
        }
      />
    ));
    return (
      <div>
        <NewCourse
          AddNewCourse={(course: CourseModel) => this.AddNewCourse(course)}
        />
        <h2>Courses Offered</h2>
        <div className="row">{coursesToBeCreated}</div>;
      </div>
    );
  }
}

export default ListOfCourses;
