import React from "react";
import { Message } from "./message.component";
export class FormMessage extends React.Component {
  state: any = { name: "" };
  render() {
    return (
      <div>
        <label htmlFor="txtName">Name : </label>
        <input
          type="text"
          id="txtName"
          onInput={(e: any) => this.setState({ name: e.target.value })}
        />
        <Message msg={this.state.name} />
      </div>
    );
  }
}
