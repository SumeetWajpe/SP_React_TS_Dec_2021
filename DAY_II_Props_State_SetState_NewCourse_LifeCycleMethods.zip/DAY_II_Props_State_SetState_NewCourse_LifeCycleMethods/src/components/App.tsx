import React from "react";
import { FormMessage } from "./formmessage.component";
import ListOfCourses from "./listofcourses.component";

class App extends React.Component {
  render(): React.ReactNode {
    return (
      <div>
        <ListOfCourses />
        {/* <FormMessage /> */}
      </div>
    );
  }
}

export default App;
