import React from "react";
import { ICourseProps } from "./ICourseProps";
import "./course.component.css";
import { ICourseState } from "./ICourseState";
class Course extends React.Component<ICourseProps, ICourseState> {
  state: Readonly<ICourseState> = { currLikes: this.props.coursedetails.likes };
  // constructor(props: ICourseProps) {
  //   super(props);
  //   this.state = { currLikes: this.props.coursedetails.likes };
  // }
  IncrementLikes() {
    // console.log("U Clicked !");
    //console.log(this);
    //this.props.coursedetails.likes++; // won't work -> props are readonly
    //console.log(this.props.coursedetails.likes);
    // this.state.currLikes++; // won't work -> state are immutable !
    // console.log("Incrementing likes !");
    this.setState({ currLikes: this.state.currLikes + 1 });
  }

  // componentWillMount() {
  //   console.log("Component Will Mount :: Course");
  // }

  // componentDidMount() {
  //   console.log("Component Did Mount :: Course ");
  // }

  componentWillUnmount() {
    // clean up
    console.log("Within componentWillUnmount :: Course!");
  }

  render(): React.ReactNode {
    // console.log("Within Render :: Course!");

    var ratings = [];
    for (let index = 0; index < this.props.coursedetails.rating; index++) {
      ratings.push(
        <i
          className="bi bi-star-fill"
          key={index}
          style={{ color: "orange", fontSize: "1.2em" }}
        ></i>
      );
    }
    return (
      <div className="col-md-3">
        <div className="card m-2 p-2">
          <img
            src={this.props.coursedetails.imageUrl}
            className="card-img-top"
            height="150px"
            alt={this.props.coursedetails.title}
          />

          <div className="card-body">
            {ratings}

            <h5 className="card-title">{this.props.coursedetails.title}</h5>

            <p className="card-text">
              Price : {this.props.coursedetails.price}
            </p>

            {/* <button
              className="btn btn-primary btn-sm"
              onClick={this.IncrementLikes.bind(this)}
            > */}
            <button
              className="btn btn-primary btn-sm m-1"
              onClick={() => this.IncrementLikes()}
            >
              {/* {this.props.coursedetails.likes} */}
              {this.state.currLikes}{" "}
            </button>
            <button
              className="btn btn-danger btn-sm"
              onClick={() =>
                this.props.DeleteAProduct(this.props.coursedetails.id)
              }
            >
              <i className="bi bi-trash-fill"></i>
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default Course;
