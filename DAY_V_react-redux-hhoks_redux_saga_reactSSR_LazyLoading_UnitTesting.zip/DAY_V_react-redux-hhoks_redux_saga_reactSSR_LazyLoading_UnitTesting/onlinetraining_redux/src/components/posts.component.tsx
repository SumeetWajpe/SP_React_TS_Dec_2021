import React, { useEffect, useState } from "react";
import axios from "axios";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { FetchPostsAsync } from "../actions/actionCreators";

// componentDidMount , componentDidUpdate
export default function Posts() {
  const { posts } = useSelector((store: any) => store);
  var dispatch = useDispatch();

  useEffect(() => {
    //dispatch(FetchPostsAsync());
    // let thePromise = axios.get("https://jsonplaceholder.typicode.com/posts");
    // thePromise
    //   .then((response) => {
    //     dispatch(FetchPosts(response.data));
    //   })
    //   .catch((err) => console.log(err));
  }, []);

  let allPostsToBeCreated = posts.map((p: any) => (
    <li key={p.id} className="list-group-item">
      {p.title}
    </li>
  ));
  return (
    <div>
      <h1>All Posts </h1>
      <button onClick={() => dispatch(FetchPostsAsync())}>
        Get All Posts !
      </button>
      <ul>{allPostsToBeCreated}</ul>
    </div>
  );
}
