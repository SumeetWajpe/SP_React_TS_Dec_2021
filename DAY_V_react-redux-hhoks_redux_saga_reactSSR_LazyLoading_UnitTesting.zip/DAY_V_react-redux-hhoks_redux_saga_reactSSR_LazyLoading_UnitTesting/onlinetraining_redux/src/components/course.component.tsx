import React from "react";
import { useDispatch } from "react-redux";
import { IncrementLikes, DeleteCourse } from "../actions/actionCreators";

export default function Course(props: any) {
  var dispatch = useDispatch();
  var ratings = [];
  for (let index = 0; index < props.coursedetails.rating; index++) {
    ratings.push(
      <i
        className="bi bi-star-fill"
        key={index}
        style={{ color: "orange", fontSize: "1.2em" }}
      ></i>
    );
  }
  return (
    <div className="col-md-3">
      <div className="card m-2 p-2">
        <img
          src={props.coursedetails.imageUrl}
          className="card-img-top"
          height="150px"
          alt={props.coursedetails.title}
        />

        <div className="card-body">
          {ratings}

          <h5 className="card-title">{props.coursedetails.title}</h5>

          <p className="card-text">Price : {props.coursedetails.price}</p>

          <button
            className="btn btn-primary btn-sm m-1"
            onClick={() => dispatch(IncrementLikes(props.coursedetails.id))}
          >
            {props.coursedetails.likes}{" "}
            <i className="bi bi-hand-thumbs-up-fill"></i>
          </button>
          <button
            className="btn btn-danger btn-sm"
            onClick={() => dispatch(DeleteCourse(props.coursedetails.id))}
          >
            <i className="bi bi-trash-fill"></i>
          </button>
        </div>
      </div>
    </div>
  );
}

// using props via the connect() method
// export default function Course(props: any) {
//   var ratings = [];
//   for (let index = 0; index < props.coursedetails.rating; index++) {
//     ratings.push(
//       <i
//         className="bi bi-star-fill"
//         key={index}
//         style={{ color: "orange", fontSize: "1.2em" }}
//       ></i>
//     );
//   }
//   return (
//     <div className="col-md-3">
//       <div className="card m-2 p-2">
//         <img
//           src={props.coursedetails.imageUrl}
//           className="card-img-top"
//           height="150px"
//           alt={props.coursedetails.title}
//         />

//         <div className="card-body">
//           {ratings}

//           <h5 className="card-title">{props.coursedetails.title}</h5>

//           <p className="card-text">Price : {props.coursedetails.price}</p>

//           <button
//             className="btn btn-primary btn-sm m-1"
//             onClick={() => props.IncrementLikes(props.coursedetails.id)}
//           >
//             {props.coursedetails.likes}{" "}
//             <i className="bi bi-hand-thumbs-up-fill"></i>
//           </button>
//           <button
//             className="btn btn-danger btn-sm"
//             onClick={() => props.DeleteCourse(props.coursedetails.id)}
//           >
//             <i className="bi bi-trash-fill"></i>
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }
