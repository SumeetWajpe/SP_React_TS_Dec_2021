import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import App from "./components/App";
import { MainApp } from "./components/connect";
import reportWebVitals from "./reportWebVitals";
import store from "./store/store";

// using the connect() method
// ReactDOM.render(
//   <Provider store={store}>
//     <MainApp />
//   </Provider>,
//   document.getElementById("root")
// );

// using useSelector Hook
ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById("root")
);
