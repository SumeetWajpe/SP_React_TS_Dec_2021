import { CourseModel } from "../models/course.model";
let index;
export function courses(defStore: any = [], action: any) {
  switch (action.type) {
    case "INCREMENT_LIKES": // use constants
      console.log("Increment Likes for " + action.theCourseId);

      index = defStore.findIndex(
        (c: CourseModel) => c.id === action.theCourseId
      );

      return [
        ...defStore.slice(0, index),
        { ...defStore[index], likes: defStore[index].likes + 1 },
        ...defStore.slice(index + 1),
      ]; // new store value

    case "DELETE_COURSE":
      index = defStore.findIndex(
        (c: CourseModel) => c.id === action.theCourseId
      );

      return [...defStore.slice(0, index), ...defStore.slice(index + 1)];

    case "ADD_NEW_COURSE":
      return [...defStore, action.newCourse];
    default:
      return defStore; // new store value
  }
}
