import { combineReducers } from "redux";
import { posts } from "./posts.reducer";
import { courses } from "./courses.reducer";
const rootReducer = combineReducers({ courses, posts });
export default rootReducer;
