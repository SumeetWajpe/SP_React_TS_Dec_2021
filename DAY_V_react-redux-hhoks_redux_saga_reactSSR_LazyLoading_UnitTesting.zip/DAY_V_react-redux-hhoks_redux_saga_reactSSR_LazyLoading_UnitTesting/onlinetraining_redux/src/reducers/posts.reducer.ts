export function posts(defStore: any = [], action: any) {
  switch (action.type) {
    case "DELETE_POST":
      return defStore; // new store value

    case "FETCH_POSTS":
      return action.posts;
    default:
      return defStore; // new store value
  }
}
