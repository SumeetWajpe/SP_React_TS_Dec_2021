import { takeLatest, call, put, retry } from "redux-saga/effects";
import axios from "axios";

interface IPosts {
  id?: number;
  userId?: number;
  title?: string;
  body?: string;
}

export interface Response {
  config?: any;
  data?: any;
  headers?: any;
  request?: any;
  status?: number;
  statusText?: string;
}

const getPost = () =>
  axios.get<IPosts[]>("https://jsonplaceholder.typicode.com/posts");

export function* fetchPostsFromAPI() {
  try {
    const response: Response = yield call(getPost); // make async req
    yield put({ type: "FETCH_POSTS", posts: response.data }); // dispatch
  } catch (error) {
    yield put({ type: "FETCH_POSTS_ERROR" });
  }
}

export function* fetchPostsFromAPIWithRetry() {
  try {
    let duration = 1000;
    let response: Response = yield retry(3, duration * 10, getPost);
    yield put({ type: "FETCH_POSTS", posts: response.data });
  } catch (error) {}
}

export function* mySaga() {
  //   yield takeLatest("FETCH_POSTS_ASYNC", fetchPostsFromAPI);
  yield takeLatest("FETCH_POSTS_ASYNC", fetchPostsFromAPIWithRetry);
}
