import axios from "axios";
import { CourseModel } from "../models/course.model";

const INCREMENT_LIKES = "INCREMENT_LIKES"; // better practice
export function IncrementLikes(theCourseId: number) {
  return { type: INCREMENT_LIKES, theCourseId };
}

export function DeleteCourse(theCourseId: number) {
  return { type: "DELETE_COURSE", theCourseId };
}

export function FetchPosts(posts: any) {
  return { type: "FETCH_POSTS" };
}

export function FetchPostsAsync() {
  return { type: "FETCH_POSTS_ASYNC" };
}
export function FetchPostError() {
  return { type: "FETCH_POSTS_ERROR" };
}

export function AddNewCourse(newCourse: CourseModel) {
  return { type: "ADD_NEW_COURSE", newCourse };
}
