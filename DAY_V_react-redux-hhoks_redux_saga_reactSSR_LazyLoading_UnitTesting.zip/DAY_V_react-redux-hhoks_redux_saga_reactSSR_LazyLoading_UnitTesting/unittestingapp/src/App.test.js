// import { render, screen } from "@testing-library/react";
// import App from "./App";

// test('renders learn react link', () => {
//   render(<App />);
//   const linkElement = screen.getByText(/learn react/i);
//   expect(linkElement).toBeInTheDocument();
// });

import Enzyme, { shallow } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import App from "./App";

Enzyme.configure({ adapter: new Adapter() });

describe('"state of counter', () => {
  it("counter is initialized to 0", () => {
    let appInstance = shallow(<App />); // generates the DOM
    let count = appInstance.state().count;
    expect(count).toBe(0);
  });
  it("counter increments to 1", () => {
    let appInstance = shallow(<App />); // generates the DOM
    let btn = appInstance.find("button");
    btn.simulate("click");
    let ptext = appInstance.find("p").text();
    expect(ptext).toEqual("Count : 1")
  });
});
