export function posts(defStore: any = [], action: any) {
  switch (action.type) {
    case "DELETE_POST":
      return defStore; // new store value
    default:
      return defStore; // new store value
  }
}
