import { CourseModel } from "../models/course.model";

export function courses(defStore: any = [], action: any) {
  switch (action.type) {
    case "INCREMENT_LIKES": // use constants
      console.log("Increment Likes for " + action.theCourseId);

      let index = defStore.findIndex(
        (c: CourseModel) => c.id === action.theCourseId
      );

      return [
        ...defStore.slice(0, index),
        { ...defStore[index], likes: defStore[index].likes + 1 },
        ...defStore.slice(index + 1),
      ]; // new store value
    default:
      return defStore; // new store value
  }
}
