import React from "react";
import { CourseModel } from "../models/course.model";
import ICoursesProps from "../models/ICoursesProps";
import Course from "./course.component";

// export default function ListOfCourses(props: ICoursesProps) {
export default function ListOfCourses(props: any) {
  var coursesToBeCreated = props.allCourses.map((course: CourseModel) => (
    <Course key={course.id} coursedetails={course} {...props} />
  ));
  return (
    <div>
      <h2>Courses Offered</h2>
      <div className="row">{coursesToBeCreated}</div>;
    </div>
  );
}
