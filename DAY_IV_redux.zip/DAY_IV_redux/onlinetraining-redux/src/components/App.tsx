import React from "react";
import ListOfCourses from "./listofcourses.component";

function App(props: any) {
  //console.log(props.allCourses);

  return (
    <div>
      <ListOfCourses {...props} />
    </div>
  );
}

export default App;
