import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { IStoreData } from "../store/store";
import * as allActions from "../actions/actionCreators";
import App from "./App";

// to expose store data to react components
function mapStateToProps(store: IStoreData) {
  return {
    allCourses: store.courses, // this.props.allCourses | props.allCourses
    allPosts: store.posts,
  };
}

// to expose actions to react components
function mapDispatchToProps(dispatch: any) {
  return bindActionCreators(allActions, dispatch);
}

export const MainApp = connect(mapStateToProps, mapDispatchToProps)(App);
