import { CourseModel } from "./course.model";

export default interface ICoursesProps {
  allCourses: CourseModel[];
}
