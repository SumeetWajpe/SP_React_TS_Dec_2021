import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import App from "./components/App";
import { MainApp } from "./components/connect";
import reportWebVitals from "./reportWebVitals";
import store from "./store/store";

ReactDOM.render(
  <Provider store={store}>
    <MainApp />
  </Provider>,
  document.getElementById("root")
);
