const INCREMENT_LIKES = "INCREMENT_LIKES"; // better practice
export function IncrementLikes(theCourseId: number) {
  return { type: INCREMENT_LIKES, theCourseId };
}

export function DeleteCourse() {
  return { type: "DELETE_COURSE" };
}
export function AddCourse() {
  return { type: "ADD_COURSE" };
}
